### Hexlet tests and linter status:
[![Actions Status](https://github.com/un-f0rgiven/python-project-52/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/un-f0rgiven/python-project-52/actions)

**Учебный проект - Менеджер задач**
<заполнить>

**Демонстрация развёрнутого приложения**
https://task-manager-yoqv.onrender.com/